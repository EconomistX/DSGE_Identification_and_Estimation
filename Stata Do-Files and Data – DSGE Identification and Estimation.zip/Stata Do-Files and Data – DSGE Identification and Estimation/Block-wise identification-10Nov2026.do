
global root "D:\BlockwiseIdentification"
use "$root/forDSGE12", clear






sort year

**Figure 1 of the Online Supplementary Appendix: Carbon emissions in the United States
	   cd "$root"  
twoway(line CO2ab_ntr_  year, lpattern(line)) (line CO2_e_ year, lpattern(dash)) (line CO2_y_ year, lpattern(dash_dot_dot)), legend(order(1 "Nature as a sink" 2 "Energy as a source" 3 "Manufacturing as a source")) xlabel(1990(5)2025) saving(CO2emissionsUS, replace) 









	   cd "$root"   	
	use "forDSGE12", clear 

		gen D_=D1
*The following defines standardized D. Y and C are already standardized.  
		* `i'_ is the value of `i' before standardization.
		* `i' below is standardized: I Y F F_y F_e E CO2_e CO2_y CO2ab_ntr CO2ab_frs CO2ab_Nefrst C Ll_e Ll_y Lh_e Lh_y K_y K_e P_e Wh Wl r R_y R_e Pop 
	local letters16 D_ 
foreach i of local letters16{
	egen  `i'std=std(`i')
	drop `i'
	gen `i'=`i'std 
	drop `i'std 
}
		
		gen D=D_ 
		drop D_ 
		
			* `i'_ is the value of `i' before standardization.
		* `i' below is standardized: I Y F F_y F_e E CO2_e CO2_y CO2ab_ntr CO2ab_frs CO2ab_Nefrst C Ll_e Ll_y Lh_e Lh_y K_y K_e P_e Wh Wl r R_y R_e Pop 
	gen a_YE=E_/TY_y  
	gen a_YF=F_/TY_y 
	gen b_EF=F_e_/E_ 
	
				  gen v=b_EF*a_YE/a_YF				
	
			bys year: egen v__=mean(v)
			drop v 
			gen v=v__ 
			drop v__
 
				  keep if NAICS==44 
				  tsset year 
				  tsline v if  year<=2024

	sum v  if year<=2024
sum C D Y if year<=2024	
	
	*Case of Bayesian DSGE: This part produces good results! It follows the bad results of traditional DSGE and conduts Bayesian estimation. As a consequence, all estimates produced are highly efficient!!!!! 
	
	*This case assume all manufacturing sector's emissions are absorbed by nature and looks at only the responsiblity of electricity sector.
   cd "$root"   	
	use "forDSGE12", clear 
	
	*The following command defines unscaled D.  Note that unscaled C is already defined previously!
	gen D_=D1
*The following defines standardized D. Y and C are already standardized earlier. 
	local letters16 D_  
foreach i of local letters16{
	egen  `i'std=std(`i')
	drop `i'
	gen `i'=`i'std 
	drop `i'std 
}
		
		gen D=D_ 
		drop D_ 
		
	
	keep if NAICS==22
	drop if year>=2024
		
	tsset year 
	
	   cd "$root"  
	   
	   *Beta distribution in the following code sets the range of estimated parameters. An example of this can be seen from pp. 139 of "STATA dynamic Stochastic General Equilibrium Models Reference Manual" where "The parameters of the beta distribution were chosen to put the weight of prior mass on theoretically appropriate values. For the discount factor {beta}, this is the range (0.90, 0.99). For the depreciation parameter {delta}, this is the range (0.03, 0.05). For the capital share {alpha}, this is the range (0.3, 0.4). For the autoregressive parameter, this is the range (0.6, 0.99)."
	   
	   
	   *Figure B1 here****
tsline C D Y

*a1=beta
*a2=Omega1
*a3=Omega2 
*a4=Omega3 
*a5=Omega4 

*a2 is Omega1 in Equation (11-1). It is written as  Ω_1={(m_E^(-1) ea_YE+m_Y^(-1) p)-((b ̃_EF a_YE+a_YF )f+ea_YE+v_K p)} p^(-1), which, for the convenience of interpretation, is written as Ω_1={((m_E^(-1)-1)e-b ̃_EF f) a_YE+((m_Y^(-1)-1)p-a_YF f)+(1-v_K)p} p^(-1) in the main text. 



*Table B2 of the Online Supplementary Appendix here********
  
      *macroeconomic block. 
bayes,  prior({a1}, beta(40,55)) prior({a2}, beta(30,45)) prior({a3}, beta(40,50)) prior({a4}, beta(20,50)) prior({a5}, normal(0.10,0.005)) thin(10) burnin(1000) adaptation(tolerance(.209)) mcmcsize(10000) corrlag(1000) rseed(2): dsgenl (F.C={a1}*C) (C={a2}*Y-{a3}*D) (F.D={a4}*Y-({a5}-1)*D), observed(Y) unobserved(C) exostate(D)  solve noidencheck post from(a1=0.45) 




bayesstats ess
bayesstats summary {a1} {a2} {a3} {a4} {a5}

*Figures C1-C5 of the Online Supplementary Appendix here******* 

bayesgraph diagnostics a1 a2 a3 a4 a5, saving(acollectforDSGE, replace)
bayes, saving(BAYDSGE1, replace)




 forval i=15000(5000)40000{
bayes,  prior({a1}, beta(40,55)) prior({a2}, beta(30,45)) prior({a3}, beta(40,50)) prior({a4}, beta(20,50)) prior({a5}, normal(0.10,0.005)) thin(10) burnin(`=`i'-9000') adaptation(tolerance(.209)) mcmcsize(`i') corrlag(1000) rseed(2): dsgenl (F.C={a1}*C) (C={a2}*Y-{a3}*D) (F.D={a4}*Y-({a5}-1)*D), observed(Y) unobserved(C) exostate(D)  solve noidencheck post from(a1=0.45) 
bayes, saving(BAYDSGE1_`i', replace)
 }



	   cd "$root"  
	   
	   

use BAYDSGE1, clear
*The following commands generate new variables to represent {a1}, {a2}, {a3}, {a4}, and {a5}. Before doing that, we need to call out the saved file "BAYDSGE1" stored using "bayes, saving(BAYDSGE1, replace)" previously to confirm how the estimates are stored and named. Thereby we generate new variables as weighted values of those estimates. See "bayes, saving" at  https://www.stata.com/manuals/bayesbayesintreg.pdf 

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a30 a40 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

gen sg0=(a20-a2)^2*_frequency
egen sg1=total(sg0)

gen sigma_a2=(sg1/totfreq)^0.5
*CI formula: x-Z*sigma/(n^0.5) \ge CI\le x+Z*sigma/(n^0.5); for alpha=0.05, Z=1.96
gen a2CIupp=a2+1.645*sigma_a2
gen a2CIlow=a2-1.645*sigma_a2
sum a1 a2 a3 a4 a5 a2CIupp a2CIlow

gen n=_n 
keep if n==1 
keep a1 a2 a3 a4 a5 a2CIupp a2CIlow

expand 20 
 
gen year=_n+2002 

merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

	   cd "$root"  
	   save "BayesianCoefficients", replace

*************************************************************************************
*************************************************************************************
************************this part compute the effort of CCS and aforestation***************
*************************************************************************************
*************************************************************************************
	   
	   
	   	   cd "$root"  
	use "BayesianCoefficients", clear 
merge n:m NAICS year using  "forDSGE12"
drop _merge 
	  
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  
	  gen D=D1 
	  drop D1 

	gen a_YE=E_/TY_y  
	gen a_YF=F_/TY_y 
	gen b_EF=F_e_/E_ 
	gen a_YL=Ll_y_/TY_y 
	gen a_YH=Lh_y_/TY_y 
	gen a_YK=K_y_/TY_y 
	*a_REE and a_RYY are adjusted using CPI (i.e. P transformed from CPI). 
	gen a_REE=(R_e_/P)/E_
gen a_RYY=(R_y_/P)/TY_y 

*In Eq (13), v_K*Y equals I and in section 2.4, I=S so v_K*Y=S. Note that I is computed to be K-K_[_n-1] and K is in real value, so I is not further deflated by CPI.
gen v_K=I_/TY_y

	gen K_=K_y_+K_e_ 
	gen K=K_ 
	drop K_ 
	
	gen b_EK=K_e_/E_  
	gen a_YEK=b_EK*a_YE
	
	*The following computes the ratio of b ̃_EF a_YE to a_YF 
*	gen relative_fossil_ratio=(b_EF*a_YE)/a_YF
	
	local letetrs00000 a_YE a_YF b_EF a_YL a_YH a_YK a_REE a_RYY K v_K b_EK a_YEK 
	foreach i of local letetrs00000 {
		gen `i'_=`i'
	egen `i'std=std(`i')
	drop `i'
	*P_e and P not standardized here are already rescaled to have mean 0 and standard deviation 1 in the part where we run the Bayesian DSGE model.
	gen `i'=`i'std 
	drop `i'std 
	}
	
	
	sort year 

	
	
	*The trend of D is consistent with that of the product of ϕ_F and Y, given a constant value of ϕ_F over time, as can be observed from the stable trend of emissions coefficients noted earlier. Thus, we assume a4=(1-{tau_s}) and obtain that tauS=1-a4.

gen tauS=1-a4

	
		
				
	*a5 is Omega4 in Equation (20-2). a3 is Omega3 in Equation (20-2).
	gen tauNX=a5-tauN0


		
	tsset year 
	*Y is standardized GDPpc, which is computed earlier. We do not use it but standardize Y_ (the unscaled GDPpc) because time interval here is different from there.

	egen stdY=std(Y_) 
	*D is previously computed as the cumulative sum of the carbon dioxide of manufacturing and electricity sectors since 1997, the resultant value of carbon stock (D) below is used as the proxy of unscaled D_t. The source of carbon dioxide is the EPA (2023b). 
egen stdD=std(D) 

*Before 2003, there is no sufficient data for simulation.
 forval j=2003(1)2022{
forval i=10(10)50{
	gen AAAA`i'_`j'=((a4*stdY)-(((tauNX+(tauN0*(`=`i'/100')))+tauN0)*stdD)) if year==`j'
	gen B`i'_`j'=((a4*stdY)-((tauNX+tauN0)*stdD))  if year==`j'
gen increment_of_stdD`i'_`j'=AAAA`i'_`j'-B`i'_`j'  if year==`j'
gen Y`i'__`j'=increment_of_stdD`i'_`j'  if year==`j'
 gen Y`i'_`j'_=Y`i'__`j'/(tauS*stdY)  if year==`j'
 }
 }

 forval j=2003(1)2022{
forval i=10(10)50{
 egen Y`i'_`j'=mean(Y`i'_`j'_)
}
 }
egen mtauNX=mean(tauNX)
egen mtauN0=mean(tauN0)
gen rtauNX=mtauNX/mtauN0
 

 
  forval j=2003(1)2022{
 sum Y10_`j' Y20_`j' Y30_`j' Y40_`j' Y50_`j'
  }

  forval i=1/5{
  gen CE`i'1=(Y`i'0_2003+Y`i'0_2004+Y`i'0_2005+Y`i'0_2006+Y`i'0_2007)/5
  gen CE`i'2=(Y`i'0_2008+Y`i'0_2009+Y`i'0_2010+Y`i'0_2011+Y`i'0_2012)/5
  gen CE`i'3=(Y`i'0_2013+Y`i'0_2014+Y`i'0_2015+Y`i'0_2016+Y`i'0_2017)/5
  gen CE`i'4=(Y`i'0_2018+Y`i'0_2019+Y`i'0_2020+Y`i'0_2021+Y`i'0_2022)/5
  }
  
  gen period=1 if year>=2003 & year<2008
forval i=1(1)3  {
  replace period=`i'+1 if year>=2003+(`i'*5) & year<2003+((`i'+1)*5)
}


  forval i=1/5{
gen CE`i'=CE`i'1 if period==1 
replace CE`i'=CE`i'2 if period==2
replace CE`i'=CE`i'3 if period==3
replace CE`i'=CE`i'4 if period==4
  }
  
gen CE1_lbl = string(CE1, "%4.2f")
gen CE2_lbl = string(CE2, "%4.2f")
gen CE3_lbl = string(CE3, "%4.2f")
gen CE4_lbl = string(CE4, "%4.2f")
gen CE5_lbl = string(CE5, "%4.2f")

*Figure D4 of the Online Supplementary Appendix here ********************************

twoway (line CE1 period, lpattern(dot) lwidth(vthin) lcolor(gs4) legend(off)) (scatter CE1 period, mlabel(CE1_lbl) msymbol(none) mlabsize(tiny)) (line CE2 period, lpattern(shortdash_dot) lwidth(thin) lcolor(gs6) legend(off)) (scatter CE2 period, mlabel(CE2_lbl) msymbol(none) mlabsize(tiny)) (line CE3 period, lpattern(dash) lwidth(medthin) lcolor(gs8) legend(off)) (scatter CE3 period, mlabel(CE3_lbl) msymbol(none) mlabsize(tiny)) (line CE4 period, lpattern(longdash) lwidth(medium) lcolor(gs10) legend(off)) (scatter CE4 period, mlabel(CE4_lbl) msymbol(none) mlabsize(tiny)) (line CE5 period, lpattern(solid) lwidth(thick) lcolor(gs12) legend(off)) (scatter CE5 period, mlabel(CE5_lbl) msymbol(none) mlabsize(tiny))
  
  
	sum tauNX rtauNX tauN0 tauS 
	  	   cd "$root"  
	save "estmatuse", replace
	  
	  
 
	  
	  
	  *****************************************************************
	  *****************************************************************
	  	*The following is for summary statistics.
	  *****************************************************************
	  *****************************************************************
			  	   cd "$root"  
	  use estmatuse, clear 
	  
	  *Unit of Consum=thousands dollars
	gen Consum=C_/1000
	
			* `i'_ is the value of `i' before standardization.
		* `i' below is standardized: I Y F F_y F_e E CO2_e CO2_y CO2ab_ntr CO2ab_frs CO2ab_Nefrst C Ll_e Ll_y Lh_e Lh_y K_y K_e P_e Wh Wl r R_y R_e Pop 
*Summary statistics 
gen GDPpc=(Y_/100000)/1000  

*Table B1 of the Online Supplementary Appendix here ****************

	asdoc sum(GDPpc Consum D P_e_ P E_ F_y_ F_e_ K_y_ K_e_ tauN0), replace



	
	
************************************************************************
************************************************************************	 
*The following is for the sectoral block******************************** 
************************************************************************
************************************************************************	 
************************************************************************
************************************************************************	 
    cd "$root"  
		   use "estmatuse", clear 




	keep if year<2024
keep if NAICS==22
	
	
	***See page 129 of "STATA BAYESIAN ANALYSIS REFERENCE MANUAL RELEASE 18" concerning "bayesmh — Bayesian models using Metropolis–Hastings algorithm"; accessed on 5 July 2023 at  https://www.stata.com/manuals/bayes.pdf
	

*adaptation(maxiter()) added below is to address the issue of "Adaptation tolerance".

*Must assign a random seed or the regression will not get the same result every time!!!
	
	
	
**Table B3 of the Online Supplementary Appendix here********* 	

tsset year 
*a2 is Omega1 in Equation (11). It is estimated from the Bayesian DSGE model and is used here for calibrating living costs. It is written as  Ω_1={(m_E^(-1) ea_YE+m_Y^(-1) p)-((b ̃_EF a_YE+a_YF )f+ea_YE+v_K p)} p^(-1), which, for the convenience of interpretation, is written as Ω_1={((m_E^(-1)-1)e-b ̃_EF f) a_YE+((m_Y^(-1)-1)p-a_YF f)+(1-v_K)p} p^(-1) in the main text. 

cd "$root"  
bayesmh (P=((((1/{mkE}-1)*P_e-(b_EF*{f}))*a_YE+P*(1/{mkY}-v_K)-a_YF*{f})/a2),likelihood(normal({var3}))) (v_K=({epsilon}*a_YK+{kappa}*a_YEK),likelihood(normal({var4}))), prior({mkE}, normal(1.3,0.40)) prior({mkY}, normal(1.40,0.100)) prior({f}, beta(40,100)) prior({epsilon}, beta(40,100)) prior({kappa}, beta(40,100)) prior({var3}, normal(11.75,0.01)) prior({var4}, normal(.35,.01)) initial( {epsilon} 0.3 {kappa} 0.19 {var4} 0.45 {mkE} 1.3)  burnin(5000) adaptation(tarate(0.23)) corrtol(0.01) mcmcsize(10000) corrlag(2000) thin(10) saving(bayesnianinf0, replace) rseed(12554) 
**Figures C6-C10 of the Online Supplementary Appendix here ********************

bayesgraph diagnostics {mkE mkY f epsilon kappa var3 var4}, saving(showdiagforall, replace)







*Table 2 of the main text  here.

cd "$root"  
bayesmh (P=((((1/{mkE}-1)*P_e-(b_EF*{f}))*a_YE+P*(1/{mkY}-v_K)-a_YF*{f})/a2CIupp),likelihood(normal({var3}))) (v_K=({epsilon}*a_YK+{kappa}*a_YEK),likelihood(normal({var4}))), prior({mkE}, normal(1.3,0.40)) prior({mkY}, normal(1.40,0.100)) prior({f}, beta(40,100)) prior({epsilon}, beta(40,100)) prior({kappa}, beta(40,100)) prior({var3}, normal(11.75,0.01)) prior({var4}, normal(.35,.01)) initial( {epsilon} 0.3 {kappa} 0.19 {var4} 0.45 {mkE} 1.3)  burnin(5000) adaptation(tarate(0.23)) corrtol(0.01) mcmcsize(10000) corrlag(2000) thin(10) saving(BayesCIupp, replace) rseed(12554) 

cd "$root"  
bayesmh (P=((((1/{mkE}-1)*P_e-(b_EF*{f}))*a_YE+P*(1/{mkY}-v_K)-a_YF*{f})/a2CIlow),likelihood(normal({var3}))) (v_K=({epsilon}*a_YK+{kappa}*a_YEK),likelihood(normal({var4}))), prior({mkE}, normal(1.3,0.40)) prior({mkY}, normal(1.40,0.100)) prior({f}, beta(40,100)) prior({epsilon}, beta(40,100)) prior({kappa}, beta(40,100)) prior({var3}, normal(11.75,0.01)) prior({var4}, normal(.35,.01)) initial( {epsilon} 0.3 {kappa} 0.19 {var4} 0.45 {mkE} 1.3)  burnin(5000) adaptation(tarate(0.23)) corrtol(0.01) mcmcsize(10000) corrlag(2000) thin(10) saving(BayesCIlow, replace) rseed(12554) 




		  	   cd "$root"  
		*Identification by comparing results of Bayesian non-linear regression with different MCMC sizes.
		forval i=15000(5000)40000{
bayesmh (P=((((1/{mkE}-1)*P_e-(b_EF*{f}))*a_YE+P*(1/{mkY}-v_K)-a_YF*{f})/a2),likelihood(normal({var3}))) (v_K=({epsilon}*a_YK+{kappa}*a_YEK),likelihood(normal({var4}))), prior({mkE}, normal(1.3,0.40)) prior({mkY}, normal(1.40,0.100)) prior({f}, beta(40,100)) prior({epsilon}, beta(40,100)) prior({kappa}, beta(40,100)) prior({var3}, normal(11.75,0.01)) prior({var4}, normal(.35,.01)) initial( {epsilon} 0.3 {kappa} 0.19 {var4} 0.45 {mkE} 1.3)  burnin(`=`i'-5000') adaptation(tarate(0.23)) corrtol(0.01) mcmcsize(`i')  corrlag(2000) thin(10) saving(bayesnianinf`i', replace) rseed(12554) 
 }	
	


	

***********************************************************************
	*Robustness of the macroeconomic block estimation* 
***********************************************************************	
	
	  cd "$root"  

use BAYDSGE1, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=0
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model
save IdentBayes0,replace


	  cd "$root"  

use BAYDSGE1_15000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=15000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes1,replace

	  cd "$root"  

use BAYDSGE1_20000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=20000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes2,replace



	  cd "$root"  

use BAYDSGE1_25000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=25000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes3,replace


	  cd "$root"  

use BAYDSGE1_30000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=30000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes4,replace


	  cd "$root"  

use BAYDSGE1_35000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=35000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes5,replace



	  cd "$root"  

use BAYDSGE1_40000, clear

egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a40 a30 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5
gen beta=a1
gen Omega1=a2
gen Omega2=a4
gen Omega3=a3
gen Omega4=a5
gen model=40000
gen n=_n 
keep if n==1 
keep beta Omega1 Omega2 Omega3 Omega4 model

save IdentBayes6,replace

	
	
	  cd "$root"  
use IdentBayes0, clear 
forval i=1(1)6{
append using IdentBayes`i'
}

gen a1=beta 
gen a2=Omega1 
gen a3=Omega2 
gen a4=Omega3 
gen a5=Omega4

forval i=1(1)5{
gen a`i'_0_=a`i' if model==0
egen a`i'_0=mean(a`i'_0_) 
drop a`i'_0_
}

forval i=1(1)5{
forval j=15000(5000)40000{
gen a`i'_`j'_=a`i' if model==`j'
egen a`i'_`j'=mean(a`i'_`j'_) 
drop a`i'_`j'_
gen r`i'_`j'=a`i'_`j'/a`i'_0 
}
}



forval j=15000(5000)40000{
	gen n_o_`j'=(`j'-15000)/5000+1 if model==`j'
	}
	
	egen num=rowtotal(n_o_*)
	
	tsset num 
	
	forval i=1(1)5{
	gen rat`i'=r`i'_15000 if num==1
	replace rat`i'=r`i'_20000 if num==2
	replace rat`i'=r`i'_25000 if num==3
		replace rat`i'=r`i'_30000 if num==4
			replace rat`i'=r`i'_35000 if num==5
				replace rat`i'=r`i'_40000 if num==6
	}
	

	*Table B4 of the Online Supplementary Appendix here ***************************
	
*beta=a1 Omega1=a2 Omega2=a3 Omega3=a4 Omega4=a5
keep rat1 rat2 rat3 rat4 rat5 


***********************************************************************
***********************************************************************
***********************************************************************
	*Robustness of the sectoral block estimation*
***********************************************************************	
***********************************************************************
***********************************************************************
	

  cd "$root"  

use bayesnianinf0, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=0
gen n=_n 
keep if n==1 
keep f mE mY kK kE model
save BayesNonlinear0,replace


	  cd "$root"  

use bayesnianinf15000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=15000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model
save BayesNonlinear1,replace

	  cd "$root"  

use bayesnianinf20000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=20000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model

save BayesNonlinear2,replace



	  cd "$root"  

use bayesnianinf25000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=25000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model

save BayesNonlinear3,replace


	  cd "$root"  

use bayesnianinf30000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=30000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model

save BayesNonlinear4,replace


	  cd "$root"  

use bayesnianinf35000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=35000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model

save BayesNonlinear5,replace



	  cd "$root"  

use bayesnianinf40000, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=40000
gen n=_n 
keep if n==1 
keep f mE mY kK kE model

save BayesNonlinear6,replace

	
	
	  cd "$root"  
use BayesNonlinear0, clear 
forval i=1(1)6{
append using BayesNonlinear`i'
}

gen a1=mE
gen a2=mY
gen a3=f 
gen a4=kK 
gen a5=kE

foreach i of numlist 1 2 3 4 5{
gen a`i'_0_=a`i' if model==0
egen a`i'_0=mean(a`i'_0_) 
drop a`i'_0_
}

foreach i of numlist 1 2 3 4 5{
forval j=15000(5000)40000{
gen a`i'_`j'_=a`i' if model==`j'
egen a`i'_`j'=mean(a`i'_`j'_) 
drop a`i'_`j'_
gen r`i'_`j'=a`i'_`j'/a`i'_0 
}
}

	
*Table B5 the Online Supplementary Appendix here *********************** 

keep r1_* r2_* r3_* r4_* r5_*





***************************************************************************************************************
***************************************************************************************************************
***********************Identification (Table 1 in the main text) *********************************************************************
***************************************************************************************************************
***************************************************************************************************************





  cd "$root"  
use BayesNonlinear0,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

merge n:m NAICS year using  "forDSGE12"
drop _merge 
merge n:m NAICS year using "estmatuse"
drop _merge 

	  
	
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  



	keep if year<2024

	
	
	
tsset year 

ren D D__ 
egen D=std(D__)

gen FC=C[_n+1]
gen FD=D[_n+1]

scalar h=0.01

*LI_macroeconomic

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FC_a1p = `i'*(FC - (a1+h)*C)
gen M`i'FC_a1n = `i'*(FC - (a1-h)*C)
gen dM`i'FCda1=(M`i'FC_a1p-M`i'FC_a1n)/(2*h)
qui sum dM`i'FCda1
scalar dM`i'FCda1= r(mean)
}


local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a2p = `i'*(C - (a2+h)*Y + a3*D)
gen M`i'C_a2n = `i'*(C - (a2-h)*Y + a3*D)
gen dM`i'Cda2=(M`i'C_a2p-M`i'C_a2n)/(2*h)
qui sum dM`i'Cda2
scalar dM`i'Cda2= r(mean)
}

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a3p = `i'*(C - a2*Y + (a3+h)*D)
gen M`i'C_a3n = `i'*(C - a2*Y + (a3-h)*D)
gen dM`i'Cda3=(M`i'C_a3p-M`i'C_a3n)/(2*h)
qui sum dM`i'Cda3
scalar dM`i'Cda3= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a4p = `i'*(FD - (a4+h)*Y + (a5-1)*D)
gen M`i'FD_a4n = `i'*(FD - (a4-h)*Y + (a5-1)*D)
gen dM`i'FDda4=(M`i'FD_a4p-M`i'FD_a4n)/(2*h)
qui sum dM`i'FDda4
scalar dM`i'FDda4= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a5p = `i'*(FD - a4*Y + (a5+h-1)*D)
gen M`i'FD_a5n = `i'*(FD - a4*Y + (a5-h-1)*D)
gen dM`i'FDda5=(M`i'FD_a5p-M`i'FD_a5n)/(2*h)
qui sum dM`i'FDda5
scalar dM`i'FDda5= r(mean)
}



*LI_sectoral

local lettersPPPPP P P_e b_EF a_YE a_YF v_K 
foreach j of local lettersPPPPP{
gen S`j'P_mEp=`j'*(P-((((1/(mE+h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen S`j'P_mEn=`j'*(P-((((1/(mE-h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen dS`j'PdmE=(S`j'P_mEp-S`j'P_mEn)/(2*h)
qui sum dS`j'PdmE
scalar dS`j'PdmE= r(mean)
gen S`j'P_mYp=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY+h)-v_K)-a_YF*f)/a2))
gen S`j'P_mYn=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY-h)-v_K)-a_YF*f)/a2))
gen dS`j'PdmY=(S`j'P_mYp-S`j'P_mYn)/(2*h)
qui sum dS`j'PdmY
scalar dS`j'PdmY= r(mean)
gen S`j'P_fp=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f+h)))*a_YE+P*(1/mY-v_K)-a_YF*(f+h))/a2))
gen S`j'P_fn=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f-h)))*a_YE+P*(1/mY-v_K)-a_YF*(f-h))/a2))
gen dS`j'Pdf=(S`j'P_fp-S`j'P_fn)/(2*h)
qui sum dS`j'Pdf
scalar dS`j'Pdf= r(mean)
}

local lettersQQQQQ a_YK a_YEK v_K 
foreach j of local lettersQQQQQ{
gen S`j'v_K_kKp=`j'*(v_K-((kK+h)*a_YK+kE*a_YEK))
gen S`j'v_K_kKn=`j'*(v_K-((kK-h)*a_YK+kE*a_YEK))
gen dS`j'v_KdkK=(S`j'v_K_kKp-S`j'v_K_kKn)/(2*h)
qui sum dS`j'v_KdkK
scalar dS`j'v_KdkK= r(mean)
gen S`j'v_K_kEp=`j'*(v_K-(kK*a_YK+(kE+h)*a_YEK))
gen S`j'v_K_kEn=`j'*(v_K-(kK*a_YK+(kE-h)*a_YEK))
gen dS`j'v_KdkE=(S`j'v_K_kEp-S`j'v_K_kEn)/(2*h)
qui sum dS`j'v_KdkE
scalar dS`j'v_KdkE= r(mean)
}


*LI_macroeconomic SVD
mata: GM=J(9,5,0)

mata: GM[1,1] = st_numscalar("dMYFCda1")
mata: GM[2,2] = st_numscalar("dMYCda2")
mata: GM[2,3] = st_numscalar("dMYCda3")
mata: GM[3,4] = st_numscalar("dMYFDda4")
mata: GM[3,5] = st_numscalar("dMYFDda5")
mata: GM[4,1] = st_numscalar("dMDFCda1")
mata: GM[5,2] = st_numscalar("dMDCda2")
mata: GM[5,3] = st_numscalar("dMDCda3")
mata: GM[6,4] = st_numscalar("dMDFDda4")
mata: GM[6,5] = st_numscalar("dMDFDda5")
mata: GM[7,1] = st_numscalar("dMCFCda1")
mata: GM[8,2] = st_numscalar("dMCCda2")
mata: GM[8,3] = st_numscalar("dMCCda3")
mata: GM[9,4] = st_numscalar("dMCFDda4")
mata: GM[9,5] = st_numscalar("dMCFDda5")


*The singular value decomposition (SVD) of the Jacobian matrix (G_M) is given by G_M = U S V', where (U'U = I) and (V'V = I). Moreover, the SVD implies that G_M v_i = s_i u_i. The columns of (V) form an orthonormal basis for the parameter space, while the columns of (U) form an orthonormal basis for the column space (image) of the Jacobian matrix. The diagonal elements of (S), known as singular values, measure the strength of the mapping between perturbations in parameter directions and the resulting changes in moments; larger singular values indicate stronger local identification along the corresponding directions.


mata:
U = .
s = .
V = .
svd(GM,U,s,V)
s
end


*LI_sectoral SVD
mata: GS=J(9,5,0)

mata: GS[1,1] = st_numscalar("dSPPdmE")
mata: GS[2,1] = st_numscalar("dSP_ePdmE")
mata: GS[3,1] = st_numscalar("dSb_EFPdmE")
mata: GS[4,1] = st_numscalar("dSa_YEPdmE")
mata: GS[5,1] = st_numscalar("dSa_YFPdmE")
mata: GS[6,1] = st_numscalar("dSv_KPdmE")

mata: GS[1,2] = st_numscalar("dSPPdmY")
mata: GS[2,2] = st_numscalar("dSP_ePdmY")
mata: GS[3,2] = st_numscalar("dSb_EFPdmY")
mata: GS[4,2] = st_numscalar("dSa_YEPdmY")
mata: GS[5,2] = st_numscalar("dSa_YFPdmY")
mata: GS[6,2] = st_numscalar("dSv_KPdmY")

mata: GS[1,3] = st_numscalar("dSPPdf")
mata: GS[2,3] = st_numscalar("dSP_ePdf")
mata: GS[3,3] = st_numscalar("dSb_EFPdf")
mata: GS[4,3] = st_numscalar("dSa_YEPdf")
mata: GS[5,3] = st_numscalar("dSa_YFPdf")
mata: GS[6,3] = st_numscalar("dSv_KPdf")

mata: GS[7,4] = st_numscalar("dSa_YKv_KdkK")
mata: GS[8,4] = st_numscalar("dSa_YEKv_KdkK")
mata: GS[9,4] = st_numscalar("dSv_Kv_KdkK")

mata: GS[7,5] = st_numscalar("dSa_YKv_KdkE")
mata: GS[8,5] = st_numscalar("dSa_YEKv_KdkE")
mata: GS[9,5] = st_numscalar("dSv_Kv_KdkE")


mata:
U = .
s = .
V = .
svd(GS,U,s,V)
s
end


************************************************************************
************************************************************************
*******************SVD of virtual full system***************************
************************************************************************
************************************************************************

***The following is for the full system.

  cd "$root"  
use BayesNonlinear0,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

merge n:m NAICS year using  "forDSGE12"
drop _merge 
merge n:m NAICS year using "estmatuse"
drop _merge 

	  
	
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  



	keep if year<2024

	
	
	
tsset year 

ren D D__ 
egen D=std(D__)

gen FC=C[_n+1]
gen FD=D[_n+1]

scalar h=0.01

*LI_macroeconomic

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FC_a1p = `i'*(FC - (a1+h)*C)
gen M`i'FC_a1n = `i'*(FC - (a1-h)*C)
gen dM`i'FCda1=(M`i'FC_a1p-M`i'FC_a1n)/(2*h)
qui sum dM`i'FCda1
scalar dM`i'FCda1= r(mean)
}


local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a2p = `i'*(C - (a2+h)*Y + a3*D)
gen M`i'C_a2n = `i'*(C - (a2-h)*Y + a3*D)
gen dM`i'Cda2=(M`i'C_a2p-M`i'C_a2n)/(2*h)
qui sum dM`i'Cda2
scalar dM`i'Cda2= r(mean)
}

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a3p = `i'*(C - a2*Y + (a3+h)*D)
gen M`i'C_a3n = `i'*(C - a2*Y + (a3-h)*D)
gen dM`i'Cda3=(M`i'C_a3p-M`i'C_a3n)/(2*h)
qui sum dM`i'Cda3
scalar dM`i'Cda3= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a4p = `i'*(FD - (a4+h)*Y + (a5-1)*D)
gen M`i'FD_a4n = `i'*(FD - (a4-h)*Y + (a5-1)*D)
gen dM`i'FDda4=(M`i'FD_a4p-M`i'FD_a4n)/(2*h)
qui sum dM`i'FDda4
scalar dM`i'FDda4= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a5p = `i'*(FD - a4*Y + (a5+h-1)*D)
gen M`i'FD_a5n = `i'*(FD - a4*Y + (a5-h-1)*D)
gen dM`i'FDda5=(M`i'FD_a5p-M`i'FD_a5n)/(2*h)
qui sum dM`i'FDda5
scalar dM`i'FDda5= r(mean)
}





local lettersPPPPP P P_e b_EF a_YE a_YF v_K 
foreach j of local lettersPPPPP{
gen S`j'P_mEp=`j'*(P-((((1/(mE+h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen S`j'P_mEn=`j'*(P-((((1/(mE-h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen dS`j'PdmE=(S`j'P_mEp-S`j'P_mEn)/(2*h)
qui sum dS`j'PdmE
scalar dS`j'PdmE= r(mean)
gen S`j'P_mYp=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY+h)-v_K)-a_YF*f)/a2))
gen S`j'P_mYn=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY-h)-v_K)-a_YF*f)/a2))
gen dS`j'PdmY=(S`j'P_mYp-S`j'P_mYn)/(2*h)
qui sum dS`j'PdmY
scalar dS`j'PdmY= r(mean)
gen S`j'P_fp=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f+h)))*a_YE+P*(1/mY-v_K)-a_YF*(f+h))/a2))
gen S`j'P_fn=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f-h)))*a_YE+P*(1/mY-v_K)-a_YF*(f-h))/a2))
gen dS`j'Pdf=(S`j'P_fp-S`j'P_fn)/(2*h)
qui sum dS`j'Pdf
scalar dS`j'Pdf= r(mean)
gen S`j'P_a2p=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/(a2+h)))
gen S`j'P_a2n=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/(a2-h)))
gen dS`j'P_da2=(S`j'P_a2p-S`j'P_a2n)/(2*h)
qui sum dS`j'P_da2
scalar dS`j'P_da2=r(mean)
}

local lettersQQQQQ a_YK a_YEK v_K 
foreach j of local lettersQQQQQ{
gen S`j'v_K_kKp=`j'*(v_K-((kK+h)*a_YK+kE*a_YEK))
gen S`j'v_K_kKn=`j'*(v_K-((kK-h)*a_YK+kE*a_YEK))
gen dS`j'v_KdkK=(S`j'v_K_kKp-S`j'v_K_kKn)/(2*h)
qui sum dS`j'v_KdkK
scalar dS`j'v_KdkK= r(mean)
gen S`j'v_K_kEp=`j'*(v_K-(kK*a_YK+(kE+h)*a_YEK))
gen S`j'v_K_kEn=`j'*(v_K-(kK*a_YK+(kE-h)*a_YEK))
gen dS`j'v_KdkE=(S`j'v_K_kEp-S`j'v_K_kEn)/(2*h)
qui sum dS`j'v_KdkE
scalar dS`j'v_KdkE= r(mean)
}



*full system SVD
mata: MM=J(18,11,0)

mata: MM[1,1] = st_numscalar("dMYFCda1")
mata: MM[2,2] = st_numscalar("dMYCda2")
mata: MM[2,3] = st_numscalar("dMYCda3")
mata: MM[3,4] = st_numscalar("dMYFDda4")
mata: MM[3,5] = st_numscalar("dMYFDda5")
mata: MM[4,1] = st_numscalar("dMDFCda1")
mata: MM[5,2] = st_numscalar("dMDCda2")
mata: MM[5,3] = st_numscalar("dMDCda3")
mata: MM[6,4] = st_numscalar("dMDFDda4")
mata: MM[6,5] = st_numscalar("dMDFDda5")
mata: MM[7,1] = st_numscalar("dMCFCda1")
mata: MM[8,2] = st_numscalar("dMCCda2")
mata: MM[8,3] = st_numscalar("dMCCda3")
mata: MM[9,4] = st_numscalar("dMCFDda4")
mata: MM[9,5] = st_numscalar("dMCFDda5")
mata: MM[10,6] = st_numscalar("dSPPdmE")
mata: MM[11,6] = st_numscalar("dSP_ePdmE")
mata: MM[12,6] = st_numscalar("dSb_EFPdmE")
mata: MM[13,6] = st_numscalar("dSa_YEPdmE")
mata: MM[14,6] = st_numscalar("dSa_YFPdmE")
mata: MM[15,6] = st_numscalar("dSv_KPdmE")

mata: MM[10,7] = st_numscalar("dSPPdmY")
mata: MM[11,7] = st_numscalar("dSP_ePdmY")
mata: MM[12,7] = st_numscalar("dSb_EFPdmY")
mata: MM[13,7] = st_numscalar("dSa_YEPdmY")
mata: MM[14,7] = st_numscalar("dSa_YFPdmY")
mata: MM[15,7] = st_numscalar("dSv_KPdmY")

mata: MM[10,8] = st_numscalar("dSPPdf")
mata: MM[11,8] = st_numscalar("dSP_ePdf")
mata: MM[12,8] = st_numscalar("dSb_EFPdf")
mata: MM[13,8] = st_numscalar("dSa_YEPdf")
mata: MM[14,8] = st_numscalar("dSa_YFPdf")
mata: MM[15,8] = st_numscalar("dSv_KPdf")


mata: MM[10,9] = st_numscalar("dSPP_da2")
mata: MM[11,9] = st_numscalar("dSP_eP_da2")
mata: MM[12,9] = st_numscalar("dSb_EFP_da2")
mata: MM[13,9] = st_numscalar("dSa_YEP_da2")
mata: MM[14,9] = st_numscalar("dSa_YFP_da2")
mata: MM[15,9] = st_numscalar("dSv_KP_da2")

mata: MM[16,10] = st_numscalar("dSa_YKv_KdkK")
mata: MM[17,10] = st_numscalar("dSa_YEKv_KdkK")
mata: MM[18,10] = st_numscalar("dSv_Kv_KdkK")

mata: MM[16,11] = st_numscalar("dSa_YKv_KdkE")
mata: MM[17,11] = st_numscalar("dSa_YEKv_KdkE")
mata: MM[18,11] = st_numscalar("dSv_Kv_KdkE")


mata:
U = .
s = .
V = .
svd(MM,U,s,V)
s
end







************************************************************************
************************************************************************
***Identification robustness********************************************
*(The following is for the 90%-CI upper bound of a2)********************
************************************************************************
************************************************************************



  cd "$root"  
use BayesCIupp,clear 



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=0
gen n=_n 
keep if n==1 
keep f mE mY kK kE model
save BayesNonlinear0upp,replace


  cd "$root"  
use BayesNonlinear0upp,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

merge n:m NAICS year using  "forDSGE12"
drop _merge 
merge n:m NAICS year using "estmatuse"
drop _merge 

	  
	
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  



	keep if year<2024

	
	
	
tsset year 

ren D D__ 
egen D=std(D__)

gen FC=C[_n+1]
gen FD=D[_n+1]

scalar h=0.01

*LI_macroeconomic

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FC_a1p = `i'*(FC - (a1+h)*C)
gen M`i'FC_a1n = `i'*(FC - (a1-h)*C)
gen dM`i'FCda1=(M`i'FC_a1p-M`i'FC_a1n)/(2*h)
qui sum dM`i'FCda1
scalar dM`i'FCda1= r(mean)
}


local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a2p = `i'*(C - (a2+h)*Y + a3*D)
gen M`i'C_a2n = `i'*(C - (a2-h)*Y + a3*D)
gen dM`i'Cda2=(M`i'C_a2p-M`i'C_a2n)/(2*h)
qui sum dM`i'Cda2
scalar dM`i'Cda2= r(mean)
}

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a3p = `i'*(C - a2*Y + (a3+h)*D)
gen M`i'C_a3n = `i'*(C - a2*Y + (a3-h)*D)
gen dM`i'Cda3=(M`i'C_a3p-M`i'C_a3n)/(2*h)
qui sum dM`i'Cda3
scalar dM`i'Cda3= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a4p = `i'*(FD - (a4+h)*Y + (a5-1)*D)
gen M`i'FD_a4n = `i'*(FD - (a4-h)*Y + (a5-1)*D)
gen dM`i'FDda4=(M`i'FD_a4p-M`i'FD_a4n)/(2*h)
qui sum dM`i'FDda4
scalar dM`i'FDda4= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a5p = `i'*(FD - a4*Y + (a5+h-1)*D)
gen M`i'FD_a5n = `i'*(FD - a4*Y + (a5-h-1)*D)
gen dM`i'FDda5=(M`i'FD_a5p-M`i'FD_a5n)/(2*h)
qui sum dM`i'FDda5
scalar dM`i'FDda5= r(mean)
}



*LI_sectoral

local lettersPPPPP P P_e b_EF a_YE a_YF v_K 
foreach j of local lettersPPPPP{
gen S`j'P_mEp=`j'*(P-((((1/(mE+h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen S`j'P_mEn=`j'*(P-((((1/(mE-h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen dS`j'PdmE=(S`j'P_mEp-S`j'P_mEn)/(2*h)
qui sum dS`j'PdmE
scalar dS`j'PdmE= r(mean)
gen S`j'P_mYp=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY+h)-v_K)-a_YF*f)/a2))
gen S`j'P_mYn=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY-h)-v_K)-a_YF*f)/a2))
gen dS`j'PdmY=(S`j'P_mYp-S`j'P_mYn)/(2*h)
qui sum dS`j'PdmY
scalar dS`j'PdmY= r(mean)
gen S`j'P_fp=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f+h)))*a_YE+P*(1/mY-v_K)-a_YF*(f+h))/a2))
gen S`j'P_fn=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f-h)))*a_YE+P*(1/mY-v_K)-a_YF*(f-h))/a2))
gen dS`j'Pdf=(S`j'P_fp-S`j'P_fn)/(2*h)
qui sum dS`j'Pdf
scalar dS`j'Pdf= r(mean)
}

local lettersQQQQQ a_YK a_YEK v_K 
foreach j of local lettersQQQQQ{
gen S`j'v_K_kKp=`j'*(v_K-((kK+h)*a_YK+kE*a_YEK))
gen S`j'v_K_kKn=`j'*(v_K-((kK-h)*a_YK+kE*a_YEK))
gen dS`j'v_KdkK=(S`j'v_K_kKp-S`j'v_K_kKn)/(2*h)
qui sum dS`j'v_KdkK
scalar dS`j'v_KdkK= r(mean)
gen S`j'v_K_kEp=`j'*(v_K-(kK*a_YK+(kE+h)*a_YEK))
gen S`j'v_K_kEn=`j'*(v_K-(kK*a_YK+(kE-h)*a_YEK))
gen dS`j'v_KdkE=(S`j'v_K_kEp-S`j'v_K_kEn)/(2*h)
qui sum dS`j'v_KdkE
scalar dS`j'v_KdkE= r(mean)
}


*LI_macroeconomic SVD
mata: GM=J(9,5,0)

mata: GM[1,1] = st_numscalar("dMYFCda1")
mata: GM[2,2] = st_numscalar("dMYCda2")
mata: GM[2,3] = st_numscalar("dMYCda3")
mata: GM[3,4] = st_numscalar("dMYFDda4")
mata: GM[3,5] = st_numscalar("dMYFDda5")
mata: GM[4,1] = st_numscalar("dMDFCda1")
mata: GM[5,2] = st_numscalar("dMDCda2")
mata: GM[5,3] = st_numscalar("dMDCda3")
mata: GM[6,4] = st_numscalar("dMDFDda4")
mata: GM[6,5] = st_numscalar("dMDFDda5")
mata: GM[7,1] = st_numscalar("dMCFCda1")
mata: GM[8,2] = st_numscalar("dMCCda2")
mata: GM[8,3] = st_numscalar("dMCCda3")
mata: GM[9,4] = st_numscalar("dMCFDda4")
mata: GM[9,5] = st_numscalar("dMCFDda5")
mata: GM

*The singular value decomposition (SVD) of the Jacobian matrix (G_M) is given by G_M = U S V', where (U'U = I) and (V'V = I). Moreover, the SVD implies that G_M v_i = s_i u_i. The columns of (V) form an orthonormal basis for the parameter space, while the columns of (U) form an orthonormal basis for the column space (image) of the Jacobian matrix. The diagonal elements of (S), known as singular values, measure the strength of the mapping between perturbations in parameter directions and the resulting changes in moments; larger singular values indicate stronger local identification along the corresponding directions.


mata:
U = .
s = .
V = .
svd(GM,U,s,V)
s
end


*LI_sectoral SVD
mata: GS=J(9,5,0)

mata: GS[1,1] = st_numscalar("dSPPdmE")
mata: GS[2,1] = st_numscalar("dSP_ePdmE")
mata: GS[3,1] = st_numscalar("dSb_EFPdmE")
mata: GS[4,1] = st_numscalar("dSa_YEPdmE")
mata: GS[5,1] = st_numscalar("dSa_YFPdmE")
mata: GS[6,1] = st_numscalar("dSv_KPdmE")

mata: GS[1,2] = st_numscalar("dSPPdmY")
mata: GS[2,2] = st_numscalar("dSP_ePdmY")
mata: GS[3,2] = st_numscalar("dSb_EFPdmY")
mata: GS[4,2] = st_numscalar("dSa_YEPdmY")
mata: GS[5,2] = st_numscalar("dSa_YFPdmY")
mata: GS[6,2] = st_numscalar("dSv_KPdmY")

mata: GS[1,3] = st_numscalar("dSPPdf")
mata: GS[2,3] = st_numscalar("dSP_ePdf")
mata: GS[3,3] = st_numscalar("dSb_EFPdf")
mata: GS[4,3] = st_numscalar("dSa_YEPdf")
mata: GS[5,3] = st_numscalar("dSa_YFPdf")
mata: GS[6,3] = st_numscalar("dSv_KPdf")

mata: GS[7,4] = st_numscalar("dSa_YKv_KdkK")
mata: GS[8,4] = st_numscalar("dSa_YEKv_KdkK")
mata: GS[9,4] = st_numscalar("dSv_Kv_KdkK")

mata: GS[7,5] = st_numscalar("dSa_YKv_KdkE")
mata: GS[8,5] = st_numscalar("dSa_YEKv_KdkE")
mata: GS[9,5] = st_numscalar("dSv_Kv_KdkE")


mata:
U = .
s = .
V = .
svd(GS,U,s,V)
s
end






************************************************************************
************************************************************************
***Identification robustness********************************************
*(The following is for the 90%-CI lower bound of a2)********************
************************************************************************
************************************************************************



  cd "$root"  
use BayesCIlow,clear 



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=0
gen n=_n 
keep if n==1 
keep f mE mY kK kE model
save BayesNonlinear0upp,replace


  cd "$root"  
use BayesNonlinear0upp,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

merge n:m NAICS year using  "forDSGE12"
drop _merge 
merge n:m NAICS year using "estmatuse"
drop _merge 

	  
	
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  



	keep if year<2024

	
	
	
tsset year 

ren D D__ 
egen D=std(D__)

gen FC=C[_n+1]
gen FD=D[_n+1]

scalar h=0.01

*LI_macroeconomic

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FC_a1p = `i'*(FC - (a1+h)*C)
gen M`i'FC_a1n = `i'*(FC - (a1-h)*C)
gen dM`i'FCda1=(M`i'FC_a1p-M`i'FC_a1n)/(2*h)
qui sum dM`i'FCda1
scalar dM`i'FCda1= r(mean)
}


local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a2p = `i'*(C - (a2+h)*Y + a3*D)
gen M`i'C_a2n = `i'*(C - (a2-h)*Y + a3*D)
gen dM`i'Cda2=(M`i'C_a2p-M`i'C_a2n)/(2*h)
qui sum dM`i'Cda2
scalar dM`i'Cda2= r(mean)
}

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a3p = `i'*(C - a2*Y + (a3+h)*D)
gen M`i'C_a3n = `i'*(C - a2*Y + (a3-h)*D)
gen dM`i'Cda3=(M`i'C_a3p-M`i'C_a3n)/(2*h)
qui sum dM`i'Cda3
scalar dM`i'Cda3= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a4p = `i'*(FD - (a4+h)*Y + (a5-1)*D)
gen M`i'FD_a4n = `i'*(FD - (a4-h)*Y + (a5-1)*D)
gen dM`i'FDda4=(M`i'FD_a4p-M`i'FD_a4n)/(2*h)
qui sum dM`i'FDda4
scalar dM`i'FDda4= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a5p = `i'*(FD - a4*Y + (a5+h-1)*D)
gen M`i'FD_a5n = `i'*(FD - a4*Y + (a5-h-1)*D)
gen dM`i'FDda5=(M`i'FD_a5p-M`i'FD_a5n)/(2*h)
qui sum dM`i'FDda5
scalar dM`i'FDda5= r(mean)
}



*LI_sectoral

local lettersPPPPP P P_e b_EF a_YE a_YF v_K 
foreach j of local lettersPPPPP{
gen S`j'P_mEp=`j'*(P-((((1/(mE+h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen S`j'P_mEn=`j'*(P-((((1/(mE-h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen dS`j'PdmE=(S`j'P_mEp-S`j'P_mEn)/(2*h)
qui sum dS`j'PdmE
scalar dS`j'PdmE= r(mean)
gen S`j'P_mYp=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY+h)-v_K)-a_YF*f)/a2))
gen S`j'P_mYn=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY-h)-v_K)-a_YF*f)/a2))
gen dS`j'PdmY=(S`j'P_mYp-S`j'P_mYn)/(2*h)
qui sum dS`j'PdmY
scalar dS`j'PdmY= r(mean)
gen S`j'P_fp=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f+h)))*a_YE+P*(1/mY-v_K)-a_YF*(f+h))/a2))
gen S`j'P_fn=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f-h)))*a_YE+P*(1/mY-v_K)-a_YF*(f-h))/a2))
gen dS`j'Pdf=(S`j'P_fp-S`j'P_fn)/(2*h)
qui sum dS`j'Pdf
scalar dS`j'Pdf= r(mean)
}

local lettersQQQQQ a_YK a_YEK v_K 
foreach j of local lettersQQQQQ{
gen S`j'v_K_kKp=`j'*(v_K-((kK+h)*a_YK+kE*a_YEK))
gen S`j'v_K_kKn=`j'*(v_K-((kK-h)*a_YK+kE*a_YEK))
gen dS`j'v_KdkK=(S`j'v_K_kKp-S`j'v_K_kKn)/(2*h)
qui sum dS`j'v_KdkK
scalar dS`j'v_KdkK= r(mean)
gen S`j'v_K_kEp=`j'*(v_K-(kK*a_YK+(kE+h)*a_YEK))
gen S`j'v_K_kEn=`j'*(v_K-(kK*a_YK+(kE-h)*a_YEK))
gen dS`j'v_KdkE=(S`j'v_K_kEp-S`j'v_K_kEn)/(2*h)
qui sum dS`j'v_KdkE
scalar dS`j'v_KdkE= r(mean)
}


*LI_macroeconomic SVD
mata: GM=J(9,5,0)

mata: GM[1,1] = st_numscalar("dMYFCda1")
mata: GM[2,2] = st_numscalar("dMYCda2")
mata: GM[2,3] = st_numscalar("dMYCda3")
mata: GM[3,4] = st_numscalar("dMYFDda4")
mata: GM[3,5] = st_numscalar("dMYFDda5")
mata: GM[4,1] = st_numscalar("dMDFCda1")
mata: GM[5,2] = st_numscalar("dMDCda2")
mata: GM[5,3] = st_numscalar("dMDCda3")
mata: GM[6,4] = st_numscalar("dMDFDda4")
mata: GM[6,5] = st_numscalar("dMDFDda5")
mata: GM[7,1] = st_numscalar("dMCFCda1")
mata: GM[8,2] = st_numscalar("dMCCda2")
mata: GM[8,3] = st_numscalar("dMCCda3")
mata: GM[9,4] = st_numscalar("dMCFDda4")
mata: GM[9,5] = st_numscalar("dMCFDda5")
mata: GM

*The singular value decomposition (SVD) of the Jacobian matrix (G_M) is given by G_M = U S V', where (U'U = I) and (V'V = I). Moreover, the SVD implies that G_M v_i = s_i u_i. The columns of (V) form an orthonormal basis for the parameter space, while the columns of (U) form an orthonormal basis for the column space (image) of the Jacobian matrix. The diagonal elements of (S), known as singular values, measure the strength of the mapping between perturbations in parameter directions and the resulting changes in moments; larger singular values indicate stronger local identification along the corresponding directions.


mata:
U = .
s = .
V = .
svd(GM,U,s,V)
s
end


*LI_sectoral SVD
mata: GS=J(9,5,0)

mata: GS[1,1] = st_numscalar("dSPPdmE")
mata: GS[2,1] = st_numscalar("dSP_ePdmE")
mata: GS[3,1] = st_numscalar("dSb_EFPdmE")
mata: GS[4,1] = st_numscalar("dSa_YEPdmE")
mata: GS[5,1] = st_numscalar("dSa_YFPdmE")
mata: GS[6,1] = st_numscalar("dSv_KPdmE")

mata: GS[1,2] = st_numscalar("dSPPdmY")
mata: GS[2,2] = st_numscalar("dSP_ePdmY")
mata: GS[3,2] = st_numscalar("dSb_EFPdmY")
mata: GS[4,2] = st_numscalar("dSa_YEPdmY")
mata: GS[5,2] = st_numscalar("dSa_YFPdmY")
mata: GS[6,2] = st_numscalar("dSv_KPdmY")

mata: GS[1,3] = st_numscalar("dSPPdf")
mata: GS[2,3] = st_numscalar("dSP_ePdf")
mata: GS[3,3] = st_numscalar("dSb_EFPdf")
mata: GS[4,3] = st_numscalar("dSa_YEPdf")
mata: GS[5,3] = st_numscalar("dSa_YFPdf")
mata: GS[6,3] = st_numscalar("dSv_KPdf")

mata: GS[7,4] = st_numscalar("dSa_YKv_KdkK")
mata: GS[8,4] = st_numscalar("dSa_YEKv_KdkK")
mata: GS[9,4] = st_numscalar("dSv_Kv_KdkK")

mata: GS[7,5] = st_numscalar("dSa_YKv_KdkE")
mata: GS[8,5] = st_numscalar("dSa_YEKv_KdkE")
mata: GS[9,5] = st_numscalar("dSv_Kv_KdkE")


mata:
U = .
s = .
V = .
svd(GS,U,s,V)
s
end










*****************************************************************************************
************Figures D1-D3 of the Online Supplementary Appendix: policy experiment on carbon taxation********************************
*****************************************************************************************

   

 
 
***25 years of tax*************************************************** 
 
   cd "$root"   	
*	use "forDSGE12", clear 
use "estmatuse", clear	


drop C_ Y_
*The following defines standardized D, C, Y. 
	local letters16 D C Y
foreach i of local letters16{
	egen  `i'std=std(`i'), mean(2)
	drop `i'
	gen `i'=`i'std 
	drop `i'std 
}
		
		
	
	keep if NAICS==22
	drop if year>2024
		
	tsset year 
	
	   cd "$root"  

	

	 keep year C D Y a1 a2 a3 a4 a5 



ren (a1 a2 a3 a4 a5) (a11 a12 a13 a14 a15)
forval i=1(1)5{
egen a`i'=mean(a1`i')
drop a1`i'
}


	   cd "$root"  
	   save BlockIdentPolicy, replace
	   
	

	  

    cd "$root"  
	   use BlockIdentPolicy, clear
	   
	   drop if year<=1990
	set seed 146512   

local a1 =0.5710
local a2 =0.3980  
local a3 =0.4456  
local a4 =0.2856  
local a5 =0.0981 

*the structural shock represents unexpected disturbances affecting the accumulation dynamics of the CO₂ stock.
gen u_2022_=0 if year==2022




set obs 100
gen t=_n-32
local lets C D Y 
foreach i of local lets{
gen `i'_0=`i' if year==2022 
}

egen u_2022=mean(u_2022_) 
gen u=rnormal(u_2022,0.01)

forval j=5(5)30{
gen tax`j'=`j'/100 if t>=0 & t<=25

gen D_s`j'=D_0 if t==0 
gen Y_s`j'=Y_0 if t==0 
gen C_s`j'=C_0 if t==0
 

replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==1
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==1
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==1

 
 
forval t=2(1)50{
replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==`t'
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==`t'
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==`t' 
}



gen D_v`j'=D_0 if t==0 
gen Y_v`j'=Y_0 if t==0 
gen C_v`j'=C_0 if t==0

replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==1
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==1
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==1
 
forval t=2(1)50{
replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==`t'
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==`t'
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==`t'
 
}


gen dD`j'_=D_v`j'-D_s`j'
gen dY`j'_=Y_v`j'-Y_s`j'
gen dC`j'_=C_v`j'-C_s`j' 

}

keep if t>=0 & t<=25

tsset t 
forval j=5(5)30{
bys t: egen dD`j'=mean(dD`j'_)
bys t: egen dY`j'=mean(dY`j'_)
bys t: egen dC`j'=mean(dC`j'_)
}


	   cd "$root"  


twoway (line dC5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dC10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dC15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dC20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dC25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dC30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 27, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(c25, replace)

twoway (line dD5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dD10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dD15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dD20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dD25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dD30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 27, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.05 -0.03) noextend) xscale(range(1 34) noextend) saving(d25, replace)


twoway (line dY5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dY10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dY15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dY20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dY25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dY30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 27, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(y25, replace)


	   

	
	
***************20 years of tax*********************************************** 
 
    cd "$root"  
	   	   use BlockIdentPolicy, clear
	   
	   drop if year<=1990
	set seed 146512   
local a1 =0.5710
local a2 =0.3980  
local a3 =0.4456  
local a4 =0.2856  
local a5 =0.0981  


*the structural shock represents unexpected disturbances affecting the accumulation dynamics of the CO₂ stock.
gen u_2022_=0 if year==2022




set obs 100
gen t=_n-32
local lets C D Y 
foreach i of local lets{
gen `i'_0=`i' if year==2022 
}

egen u_2022=mean(u_2022_) 
gen u=rnormal(u_2022,0.01)

forval j=5(5)30{
gen tax`j'=`j'/100 if t>=0 & t<=20
gen D_s`j'=D_0 if t==0 
gen Y_s`j'=Y_0 if t==0 
gen C_s`j'=C_0 if t==0
 

replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==1
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==1
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==1

 
 
forval t=2(1)50{
replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==`t'
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==`t'
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==`t' 
}



gen D_v`j'=D_0 if t==0 
gen Y_v`j'=Y_0 if t==0 
gen C_v`j'=C_0 if t==0

replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==1
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==1
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==1
 
forval t=2(1)50{
replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==`t'
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==`t'
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==`t'
 
}


gen dD`j'_=D_v`j'-D_s`j'
gen dY`j'_=Y_v`j'-Y_s`j'
gen dC`j'_=C_v`j'-C_s`j' 

}

keep if t>=0 & t<=25

tsset t 
forval j=5(5)30{
bys t: egen dD`j'=mean(dD`j'_)
bys t: egen dY`j'=mean(dY`j'_)
bys t: egen dC`j'=mean(dC`j'_)
}



	   cd "$root"  


twoway (line dC5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dC10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dC15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dC20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dC25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dC30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 22, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(c20, replace)

twoway (line dD5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dD10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dD15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dD20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dD25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dD30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 22, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.05 -0.03) noextend) xscale(range(1 34) noextend) saving(d20, replace)


twoway (line dY5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dY10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dY15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dY20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dY25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dY30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 22, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(y20, replace)


   
	
	


	***************15 years of tax*********************************************** 
 
    cd "$root"  
	 	   use BlockIdentPolicy, clear
	   
	   drop if year<=1990
	set seed 146512   
local a1 =0.5710
local a2 =0.3980  
local a3 =0.4456  
local a4 =0.2856  
local a5 =0.0981 


*the structural shock represents unexpected disturbances affecting the accumulation dynamics of the CO₂ stock.
gen u_2022_=0 if year==2022




set obs 100
gen t=_n-32
local lets C D Y 
foreach i of local lets{
gen `i'_0=`i' if year==2022 
}

egen u_2022=mean(u_2022_) 
gen u=rnormal(u_2022,0.01)

forval j=5(5)30{
gen tax`j'=`j'/100 if t>=0 & t<=15

gen D_s`j'=D_0 if t==0 
gen Y_s`j'=Y_0 if t==0 
gen C_s`j'=C_0 if t==0
 

replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==1
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==1
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==1

 
 
forval t=2(1)50{
replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==`t'
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==`t'
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==`t' 
}



gen D_v`j'=D_0 if t==0 
gen Y_v`j'=Y_0 if t==0 
gen C_v`j'=C_0 if t==0

replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==1
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==1
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==1
 
forval t=2(1)50{
replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==`t'
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==`t'
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==`t'
 
}


gen dD`j'_=D_v`j'-D_s`j'
gen dY`j'_=Y_v`j'-Y_s`j'
gen dC`j'_=C_v`j'-C_s`j' 

}

keep if t>=0 & t<=25

tsset t 
forval j=5(5)30{
bys t: egen dD`j'=mean(dD`j'_)
bys t: egen dY`j'=mean(dY`j'_)
bys t: egen dC`j'=mean(dC`j'_)
}


	   cd "$root"  


twoway (line dC5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dC10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dC15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dC20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dC25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dC30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 17, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(c15, replace)

twoway (line dD5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dD10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dD15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dD20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dD25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dD30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 17, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.05 -0.03) noextend) xscale(range(1 34) noextend) saving(d15, replace)


twoway (line dY5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dY10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dY15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dY20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dY25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dY30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 17, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(y15, replace)



	

	
	***************10 years of tax*********************************************** 
 
    cd "$root"  
	 	   use BlockIdentPolicy, clear
	   
	   drop if year<=1990
	set seed 146512   
local a1 =0.5710
local a2 =0.3980  
local a3 =0.4456  
local a4 =0.2856  
local a5 =0.0981 


*the structural shock represents unexpected disturbances affecting the accumulation dynamics of the CO₂ stock.
gen u_2022_=0 if year==2022




set obs 100
gen t=_n-32
local lets C D Y 
foreach i of local lets{
gen `i'_0=`i' if year==2022 
}

egen u_2022=mean(u_2022_) 
gen u=rnormal(u_2022,0.01)

forval j=5(5)30{
gen tax`j'=`j'/100 if t>=0 & t<=10

gen D_s`j'=D_0 if t==0 
gen Y_s`j'=Y_0 if t==0 
gen C_s`j'=C_0 if t==0
 

replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==1
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==1
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==1

 
 
forval t=2(1)50{
replace C_s`j'=`a1'*C_s`j'[_n-1]+u if t==`t'
replace D_s`j'=`a4'*Y_s`j'[_n-1]-(`a5'-1)*D_s`j'[_n-1]+u if t==`t'
replace Y_s`j'=(C_s`j'+`a3'*D_s`j')/`a2' if t==`t' 
}



gen D_v`j'=D_0 if t==0 
gen Y_v`j'=Y_0 if t==0 
gen C_v`j'=C_0 if t==0

replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==1
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==1
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==1
 
forval t=2(1)50{
replace C_v`j'=(1-tax`j')*`a1'*C_v`j'[_n-1]+u if t==`t'
replace D_v`j'=`a4'*Y_v`j'[_n-1]-((1+tax`j')*`a5'-1)*D_v`j'[_n-1]+u if t==`t'
replace Y_v`j'=(C_v`j'+`a3'*D_v`j')/`a2' if t==`t'
 
}


gen dD`j'_=D_v`j'-D_s`j'
gen dY`j'_=Y_v`j'-Y_s`j'
gen dC`j'_=C_v`j'-C_s`j' 

}

keep if t>=0 & t<=25

tsset t 
forval j=5(5)30{
bys t: egen dD`j'=mean(dD`j'_)
bys t: egen dY`j'=mean(dY`j'_)
bys t: egen dC`j'=mean(dC`j'_)
}



	   cd "$root"  


twoway (line dC5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dC10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dC15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dC20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dC25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dC30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 12, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(c10, replace)

twoway (line dD5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dD10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dD15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dD20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dD25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dD30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 12, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.05 -0.03) noextend) xscale(range(1 34) noextend) saving(d10, replace)


twoway (line dY5  t, lpattern(dot) lcolor(black) lwidth(vthin)) (line dY10 t, lpattern(shortdash) lcolor(black) lwidth(thin)) (line dY15 t, lpattern(dash) lcolor(black) lwidth(medium)) (line dY20 t, lpattern(longdash)   lcolor(black) lwidth(medthick)) (line dY25 t, lpattern(dash_dot) lcolor(black) lwidth(thick)) (line dY30 t, lpattern(solid) lcolor(black) lwidth(thick)), yline(0, lpattern(solid) lcolor(red)) xline(3 12, lpattern(solid) lcolor(gs10) lwidth(thin)) xlabel(1(2)34) ylabel(none) xtitle("") legend(off) yscale(range(0.1 -1) noextend) xscale(range(1 34) noextend) saving(y10, replace)


	   
	*Figures D1-D3 of the Online Supplementary Appendix
		   cd "$root"  
		   gr combine c10.gph c15.gph c20.gph, col(1) saving(c, replace)
		   gr combine y10.gph y15.gph y20.gph, col(1) saving(y, replace)
		   gr combine d10.gph d15.gph d20.gph, col(1) saving(d, replace)
		   
		   
		   
		   
	
	
	*The following computes the ratio of the fossil-fuel input-output coefficient in the electricity sector to that in the manufacturing sector, used in the analysis in Appendix B2.
	
	   	   cd "$root"  
	use "BayesianCoefficients", clear 
merge n:m NAICS year using  "forDSGE12"
drop _merge 
	  
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  
	  gen D=D1 
	  drop D1 

	
	gen a_YE=E_/TY_y  
	gen a_YF=F_/TY_y 
	gen b_EF=F_e_/E_ 
	
				  gen v=b_EF*a_YE/a_YF				
	sum v
	
	
	
	******************************************************************************
	******************************************************************************
	*******Tables B6 and B7 of the Online Supplementary Appendix: Enlarged Sample*********************
	******************************************************************************
	******************************************************************************
	******************************************************************************
	
	
	*****Expanded macroeconomic block***************************************************
	
	  cd "$root"  

use "paneltemplate", clear 
bys NAICS: gen n=_n 
keep if n==1 
drop n year
expand 65
bys NAICS: gen year=1959+_n
save "Newpaneltemplate", replace

use BayesNonlinear0,clear

expand 50
gen year=1979+_n


merge 1:n year using "Newpaneltemplate"
drop _merge
sort NAICS year

merge n:m NAICS year using  "forDSGE12"
drop _merge

merge n:m NAICS year using "estmatuse"
drop _merge

merge n:m NAICS year using "consump2"
drop _merge

merge n:m NAICS year using "Y_macro2"
drop _merge


drop Y C Y_ C_

ren (consump Y_macro) (C_ Y_)

local lettersCY C Y
foreach i of local lettersCY{
egen `i'=std(`i'_)
}

keep if NAICS==22

drop Y10_* Y20_* Y30_* Y40_* Y50_* AAAA* B10_* B20_* B30_* B40_* B50_* increment_of_* CE*

keep if year>=1980


ren (a1 a2 a3 a4 a5) (a10 a20 a30 a40 a50)

forval i=1(1)5{
egen a`i'=max(a`i'0)
}

drop a10 a20 a30 a40 a50



egen Dooo=std(D) 
drop D 
ren Dooo D 

*D_t-D_{t-1}=a4*Y_{t-1}-a5*D_{t-1}
*(a5-1)*D_{t-1}=a4*Y_{t-1}-D_t
*D_{t-1}=(a4*Y_{t-1}-D_t)/(a5-1)


gen D1990o=D if year==1990
egen D1990=mean(D1990o)


*D_t-D_{t-1}=a4*Y_{t-1}-a5*D_{t-1}
forval z=1990(-1)1980{
gen Y`z'=Y if year==`z' 
gen CHGD`z'_=a4*Y-a5*D`z' if year==`z'
egen CHGD`z'=mean(CHGD`z'_)
gen D___bf_la_haha`=`z'-1'=D`z'+CHGD`z' if year==`z'
egen D`=`z'-1'=mean(D___bf_la_haha`=`z'-1')
}

egen Dbfor1990=rowtotal(D___bf_la_haha*)
gen Dforuse=Dbfor1990 if year<1990 
replace Dforuse=D if year>=1990

drop D 
ren Dforuse D 

sort NAICS year 
save ExpandSetDSGE, replace 

use ExpandSetDSGE, clear

***Table B6 of the Online Supplementary Appendix*******************

	  cd "$root"  

keep if year<=2024 & year>=1980
tsset year
bayes,  prior({a1}, beta(40,55)) prior({a2}, beta(30,45)) prior({a3}, beta(40,50)) prior({a4}, beta(20,50)) prior({a5}, normal(0.10,0.005)) thin(20) burnin(5000) adaptation(tolerance(.209)) mcmcsize(10000) corrlag(1000) rseed(2): dsgenl (F.C={a1}*C) (C={a2}*Y-{a3}*D) (F.D={a4}*Y-({a5}-1)*D), observed(Y) unobserved(C) exostate(D)  solve noidencheck post from(a1=0.45) 
bayes, saving(Macroblk, replace)

save MacroDSGEIDENT, replace


************************Extended sectoral block*******************************************************



  cd "$root"  
use BayesNonlinear0,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 
save oldsectorcoeff, replace






import excel "$root/avgprice_annual.xlsx", sheet("Price") cellrange(A2) firstrow clear

 keep if State=="US" & IndustrySectorCategory=="Total Electric Industry" 
 
 drop Other IndustrySectorCategory State 
 destring, replace force 
 local letters6 Residential Commercial Industrial Transportation Total
 foreach i of local letters6{
 gen Pelctr_`i'=`i'
 drop `i'
 }
 gen year=Year 
 drop Year 
 sort year 
 merge n:m year using "paneltemplate"
 drop _merge 
 
 keep if NAICS!=.
 sort NAICS year 


cd "$root"
merge n:m NAICS year using "L_YnPnCnMPs_K_AI_RnD_bkyr_Ccapt_Cmanuf_Cenergy2"
drop _merge

bys NAICS: gen Invest=Ktotal-Ktotal[_n-1]

ren (Pelctr_Industrial CPI Y_macro Ktotal Invest) (P_e P TY K I)

 gen P_=P/100 
	drop P 
	gen P=P_ 
	drop P_ 
 



save TY_K_P_Pe, replace


 import excel "$root\Energy_Consumption_RCI_sectors.xlsx", sheet("Annual Data") cellrange(A11) firstrow clear


 drop if AnnualTotal==.
 
 ren AnnualTotal year 
 
  gen ElectricityInd=M
 
 gen TotalEnergyInd=TotalEnergyConsumedbytheInd
 

 destring, replace force
  keep year ElectricityInd TotalEnergyInd
 sort year  
 gen yearEngtot=year 

 	  cd "$root"  
  merge 1:m year using "paneltemplate"
  drop _merge 
   sort NAICS year 
    gen NAICSEngtot=NAICS  
 *Industry with NAICS code is Construction industry. It is classified as Industry alongside manufacturing industries.  *The following codes industries according to the "Production Account Codes" in the "NAICS codes" sheet in file "industry-production-account-capital.xlsx".
* gen sector="industry" if NAICS==23 | NAICS==321 | NAICS==327 | NAICS==331 | NAICS==332 | NAICS==333 | NAICS==334 | NAICS==335 | NAICS==3361 | NAICS==3364 | NAICS==337 | NAICS==339 | NAICS==311 | NAICS==313 | NAICS==315 | NAICS==322 | NAICS==323 | NAICS==324 | NAICS==325 | NAICS==326 | NAICS==511 | NAICS==512 | NAICS==513 | NAICS==514

 gen industry=1 if NAICS==321 | NAICS==327 | NAICS==331 | NAICS==332 | NAICS==333 | NAICS==334 | NAICS==335 | NAICS==3361 | NAICS==3364 | NAICS==337 | NAICS==339 | NAICS==311 | NAICS==313 | NAICS==315 | NAICS==322 | NAICS==323 | NAICS==324 | NAICS==325 | NAICS==326 | NAICS==511 | NAICS==512 | NAICS==513 | NAICS==514
 gen energy=1 if NAICS==22 

	  cd "$root"  
merge n:m NAICS year using TY_K_P_Pe 
drop _merge 
merge n:m NAICS year using  coaluse
drop _merge 

ren ElectricityInd E_y


ren (coalusedbyInd coalusedbyElectr) (F_y F_e)

 




 
local lettersdsgeuse TY K I
foreach i of local lettersdsgeuse{
bys year: egen `i'_y_=mean(`i') if industry==1
bys year: egen `i'_y=mean(`i'_y_) 
bys year: egen `i'_e_=mean(`i') if energy==1 
bys year: egen `i'_e=mean(`i'_e_)
drop `i'_e_ `i'_y_
}

*Unit of Pop is hundred thousand, while unit of Population is person.
gen Pop=Population/100000 
*Unit of TY_y is million dollars.
*Unit of Y is 1000000/1000=1000 (i.e. 1 thousand).
gen Y=TY_y/Pop  

local lettersdsueuse2 F_y F_e E_y P_e Pop 
foreach i of local lettersdsueuse2{
	bys year: egen `i'_=mean(`i')
	drop `i'
	gen `i'=`i'_ 
drop `i'_
}

ren E_y E
gen F=F_y+F_e 

	local letters15 I Y F F_y F_e E K_y K_e P_e Pop 
	foreach i of local letters15 {
		ipolate `i' year, gen(`i'_)
		* `i'_ is the value of `i' before standardization.
		* `i' below is standardized.
		drop `i'
		gen `i'=`i'_ 
		egen `i'std=std(`i')
		drop `i'
		gen `i'=`i'std 
		drop `i'std
	}
	


	gen a_YE=E_/TY_y  
	gen a_YF=F_/TY_y 
	gen b_EF=F_e_/E_ 
	
				  gen v=b_EF*a_YE/a_YF				
	
		

gen v_K=I_/TY_y
	
	
	gen b_EK=K_e_/E_  
	gen a_YEK=b_EK*a_YE

	gen a_YK=K_y_/TY_y 

	   cd "$root"  
save ExpndDta_Sector, replace 



	   cd "$root"  
	   
	       

use Macroblk, clear

*a2=Omega1 
*CI formula: x-Z*sigma/(n^0.5) \ge CI\le x+Z*sigma/(n^0.5); for alpha=0.05, Z=1.96
egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5) (a10 a20 a30 a40 a50)
forval i=1(1)5{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

gen sg0=(a20-a2)^2*_frequency
egen sg1=total(sg0)

gen sigma_a2=(sg1/totfreq)^0.5
gen a2CIupp=a2+1.96*sigma_a2
gen a2CIlow=a2-1.96*sigma_a2
sum a1 a2 a3 a4 a5 a2CIupp a2CIlow

gen n=_n 
keep if n==1 
keep a1 a2 a3 a4 a5 a2CIupp a2CIlow

expand 45 
 
gen year=_n+1979 

	  cd "$root"  
merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 
merge n:m NAICS year using "ExpndDta_Sector" 
drop _merge 
merge n:m year using "oldsectorcoeff" 
drop _merge


keep if NAICS==22

keep if year>=1980 & year<=2024
tsset year 


*expand the dataset using existing data and parameters back to 1990.
gen P_e_bf90_1=((a2*P-P*(1/mY-v_K)+a_YF*f)/a_YE+(b_EF*f))/(1/mE-1) if year<1990 
egen P_e_bf90_2=std(P_e_bf90_1)
gen P_e_bf90_2_89=P_e_bf90_2 if year==1989 
egen P_e_bf90_3=mean(P_e_bf90_2_89) 
gen disP_e_90=P_e_bf90_3-P_e if year==1990
egen disP_e=mean(disP_e_90) 
gen Price_e=P_e_bf90_2-disP_e  if year<1990

replace Price_e=P_e if year>=1990 
drop P_e 
gen P_e=Price_e 
drop Price_e P_e_bf90* 

***Table B7 of the Online Supplementary Appendix*******************
cd "$root"  
bayesmh (P=((((1/{mkE}-1)*P_e-(b_EF*{f}))*a_YE+P*(1/{mkY}-v_K)-a_YF*{f})/a2), likelihood(normal({var3}))) (v_K=({epsilon}*a_YK+{kappa}*a_YEK), likelihood(normal({var4}))), prior({mkE}, normal(1.1,0.01))  prior({mkY}, normal(1.01,0.0100)) prior({f}, beta(2,5)) prior({epsilon}, beta(2,5)) prior({kappa}, beta(2,5)) prior({var3}, beta(10,10)) prior({var4}, beta(50,50)) burnin(10000) thin(10) initial({epsilon} 0.3 {kappa} 0.3 {mkE} 1.1) adaptation(tarate(0.234) tolerance(0.01) every(100) maxiter(100)) corrtol(0.01) mcmcsize(50000) corrlag(2000) saving(sectorblk_extend, replace) rseed(12554)
 
 





***********************Identification for the Enlarged Sample in Online Supplementary Appendix B5***************************************



  cd "$root"  

use sectorblk_extend, clear



egen totfreq=total(_frequency)
ren (eq0_p1 eq0_p2 eq0_p3 eq0_p4 eq0_p5 eq0_p6 eq0_p7) (a10 a20 a40 a30 a50 a60 a70)
forval i=1(1)7{
gen a`i'_=a`i'0*_frequency/totfreq
egen a`i'=total(a`i'_)
}

sum a1 a2 a3 a4 a5 a6 a7 

gen f=a1 
gen mE=a2 
gen mY=a4
gen kK=a5
gen kE=a6 


gen model=0
gen n=_n 
keep if n==1 
keep f mE mY kK kE model
save sectorblk_extend_IDNT,replace










  cd "$root"  
use sectorblk_extend_IDNT,clear 

expand 50 
gen year=1979+_n


merge 1:n year using "paneltemplate"
drop _merge 
sort NAICS year 

merge n:m NAICS year using  "ExpandSetDSGE"
drop _merge 
merge n:m NAICS year using "ExpndDta_Sector"
drop _merge 

	  
	
	  keep if NAICS==22 
	  keep if year<=2024
	  
	  	   cd "$root"  
		  
	  tsset year  



	keep if year<2024

	
	
	
tsset year 

ren D D__ 
egen D=std(D__)

gen FC=C[_n+1]
gen FD=D[_n+1]

scalar h=0.01

*LI_macroeconomic

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FC_a1p = `i'*(FC - (a1+h)*C)
gen M`i'FC_a1n = `i'*(FC - (a1-h)*C)
gen dM`i'FCda1=(M`i'FC_a1p-M`i'FC_a1n)/(2*h)
qui sum dM`i'FCda1
scalar dM`i'FCda1= r(mean)
}


local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a2p = `i'*(C - (a2+h)*Y + a3*D)
gen M`i'C_a2n = `i'*(C - (a2-h)*Y + a3*D)
gen dM`i'Cda2=(M`i'C_a2p-M`i'C_a2n)/(2*h)
qui sum dM`i'Cda2
scalar dM`i'Cda2= r(mean)
}

local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'C_a3p = `i'*(C - a2*Y + (a3+h)*D)
gen M`i'C_a3n = `i'*(C - a2*Y + (a3-h)*D)
gen dM`i'Cda3=(M`i'C_a3p-M`i'C_a3n)/(2*h)
qui sum dM`i'Cda3
scalar dM`i'Cda3= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a4p = `i'*(FD - (a4+h)*Y + (a5-1)*D)
gen M`i'FD_a4n = `i'*(FD - (a4-h)*Y + (a5-1)*D)
gen dM`i'FDda4=(M`i'FD_a4p-M`i'FD_a4n)/(2*h)
qui sum dM`i'FDda4
scalar dM`i'FDda4= r(mean)
}



local lettersYDC Y D C
foreach i of local lettersYDC{
gen M`i'FD_a5p = `i'*(FD - a4*Y + (a5+h-1)*D)
gen M`i'FD_a5n = `i'*(FD - a4*Y + (a5-h-1)*D)
gen dM`i'FDda5=(M`i'FD_a5p-M`i'FD_a5n)/(2*h)
qui sum dM`i'FDda5
scalar dM`i'FDda5= r(mean)
}



*LI_sectoral

local lettersPPPPP P P_e b_EF a_YE a_YF v_K 
foreach j of local lettersPPPPP{
gen S`j'P_mEp=`j'*(P-((((1/(mE+h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen S`j'P_mEn=`j'*(P-((((1/(mE-h)-1)*P_e-(b_EF*f))*a_YE+P*(1/mY-v_K)-a_YF*f)/a2))
gen dS`j'PdmE=(S`j'P_mEp-S`j'P_mEn)/(2*h)
qui sum dS`j'PdmE
scalar dS`j'PdmE= r(mean)
gen S`j'P_mYp=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY+h)-v_K)-a_YF*f)/a2))
gen S`j'P_mYn=`j'*(P-((((1/mE-1)*P_e-(b_EF*f))*a_YE+P*(1/(mY-h)-v_K)-a_YF*f)/a2))
gen dS`j'PdmY=(S`j'P_mYp-S`j'P_mYn)/(2*h)
qui sum dS`j'PdmY
scalar dS`j'PdmY= r(mean)
gen S`j'P_fp=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f+h)))*a_YE+P*(1/mY-v_K)-a_YF*(f+h))/a2))
gen S`j'P_fn=`j'*(P-((((1/mE-1)*P_e-(b_EF*(f-h)))*a_YE+P*(1/mY-v_K)-a_YF*(f-h))/a2))
gen dS`j'Pdf=(S`j'P_fp-S`j'P_fn)/(2*h)
qui sum dS`j'Pdf
scalar dS`j'Pdf= r(mean)
}

local lettersQQQQQ a_YK a_YEK v_K 
foreach j of local lettersQQQQQ{
gen S`j'v_K_kKp=`j'*(v_K-((kK+h)*a_YK+kE*a_YEK))
gen S`j'v_K_kKn=`j'*(v_K-((kK-h)*a_YK+kE*a_YEK))
gen dS`j'v_KdkK=(S`j'v_K_kKp-S`j'v_K_kKn)/(2*h)
qui sum dS`j'v_KdkK
scalar dS`j'v_KdkK= r(mean)
gen S`j'v_K_kEp=`j'*(v_K-(kK*a_YK+(kE+h)*a_YEK))
gen S`j'v_K_kEn=`j'*(v_K-(kK*a_YK+(kE-h)*a_YEK))
gen dS`j'v_KdkE=(S`j'v_K_kEp-S`j'v_K_kEn)/(2*h)
qui sum dS`j'v_KdkE
scalar dS`j'v_KdkE= r(mean)
}


*LI_macroeconomic SVD
mata: GM=J(9,5,0)

mata: GM[1,1] = st_numscalar("dMYFCda1")
mata: GM[2,2] = st_numscalar("dMYCda2")
mata: GM[2,3] = st_numscalar("dMYCda3")
mata: GM[3,4] = st_numscalar("dMYFDda4")
mata: GM[3,5] = st_numscalar("dMYFDda5")
mata: GM[4,1] = st_numscalar("dMDFCda1")
mata: GM[5,2] = st_numscalar("dMDCda2")
mata: GM[5,3] = st_numscalar("dMDCda3")
mata: GM[6,4] = st_numscalar("dMDFDda4")
mata: GM[6,5] = st_numscalar("dMDFDda5")
mata: GM[7,1] = st_numscalar("dMCFCda1")
mata: GM[8,2] = st_numscalar("dMCCda2")
mata: GM[8,3] = st_numscalar("dMCCda3")
mata: GM[9,4] = st_numscalar("dMCFDda4")
mata: GM[9,5] = st_numscalar("dMCFDda5")
mata: GM

*The singular value decomposition (SVD) of the Jacobian matrix (G_M) is given by G_M = U S V', where (U'U = I) and (V'V = I). Moreover, the SVD implies that G_M v_i = s_i u_i. The columns of (V) form an orthonormal basis for the parameter space, while the columns of (U) form an orthonormal basis for the column space (image) of the Jacobian matrix. The diagonal elements of (S), known as singular values, measure the strength of the mapping between perturbations in parameter directions and the resulting changes in moments; larger singular values indicate stronger local identification along the corresponding directions.


mata:
U = .
s = .
V = .
svd(GM,U,s,V)
s
end


*LI_sectoral SVD
mata: GS=J(9,5,0)

mata: GS[1,1] = st_numscalar("dSPPdmE")
mata: GS[2,1] = st_numscalar("dSP_ePdmE")
mata: GS[3,1] = st_numscalar("dSb_EFPdmE")
mata: GS[4,1] = st_numscalar("dSa_YEPdmE")
mata: GS[5,1] = st_numscalar("dSa_YFPdmE")
mata: GS[6,1] = st_numscalar("dSv_KPdmE")

mata: GS[1,2] = st_numscalar("dSPPdmY")
mata: GS[2,2] = st_numscalar("dSP_ePdmY")
mata: GS[3,2] = st_numscalar("dSb_EFPdmY")
mata: GS[4,2] = st_numscalar("dSa_YEPdmY")
mata: GS[5,2] = st_numscalar("dSa_YFPdmY")
mata: GS[6,2] = st_numscalar("dSv_KPdmY")

mata: GS[1,3] = st_numscalar("dSPPdf")
mata: GS[2,3] = st_numscalar("dSP_ePdf")
mata: GS[3,3] = st_numscalar("dSb_EFPdf")
mata: GS[4,3] = st_numscalar("dSa_YEPdf")
mata: GS[5,3] = st_numscalar("dSa_YFPdf")
mata: GS[6,3] = st_numscalar("dSv_KPdf")

mata: GS[7,4] = st_numscalar("dSa_YKv_KdkK")
mata: GS[8,4] = st_numscalar("dSa_YEKv_KdkK")
mata: GS[9,4] = st_numscalar("dSv_Kv_KdkK")

mata: GS[7,5] = st_numscalar("dSa_YKv_KdkE")
mata: GS[8,5] = st_numscalar("dSa_YEKv_KdkE")
mata: GS[9,5] = st_numscalar("dSv_Kv_KdkE")


mata:
U = .
s = .
V = .
svd(GS,U,s,V)
s
end









